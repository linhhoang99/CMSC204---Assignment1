/**
 * @author Linh Hoang
 * CMSC 204 
 * 12/09/2020
 * An utility class that is used to check passwords
 */

import java.util.ArrayList;
import java.util.regex.*;

public final class PasswordCheckerUtility {
	

	/**
	 * Compare equality of two passwords
	 * @param password
	 * @param passwordConfirm
	 * @throws UnmatchedException - thrown if not same length
	 */
	public static void comparePasswords(String password, String passwordConfirm) throws UnmatchedException {
		if(!comparePasswordsWithReturn(password,passwordConfirm))
			throw new UnmatchedException() ;
		
	}
	
	/**
	 * Compare two passwords( with return) to check similarities
	 * @param password
	 * @param passwordConfirm
	 * @return false if two passwords are not the same - else true
	 */
	public static boolean comparePasswordsWithReturn(String password, String passwordConfirm) {

		if(!(password.equals(passwordConfirm)))
				return false;
		else
				return true;
			
	}
	
	/**
	 * Checks the password length requirement - � The password must be at least 6 characters long
	 * @param password - password string to be checked
	 * @return true if the password meet requirement
	 * @throws LengthException  - thrown if does not meet min length requirement (6)
	 */
	public static boolean isValidLength(String password) throws LengthException {
		if(password.length()>=6)
			return true;
		else 
			throw new LengthException();
	}
	
	/**
	 * Checks the password alpha character requirement - Password must contain an uppercase alpha character
	 * @param p - password string to be checked
	 * @return true if password has an upper case alpha
	 * @throws NoUpperAlphaException
	 */
	public static boolean hasUpperAlpha (String p) throws NoUpperAlphaException {
		for( int index = 0; index < p.length(); index++ )
		{
			char character = p.charAt(index);
			if(Character.isUpperCase(character))
				return true;
		}
		throw new NoUpperAlphaException();
	}
	
	/**
	 * Checks the password lower case requirement - Password must contain a lower case alpha character
	 * @param p - password string to be checked
	 * @return true if password has an lower case alpha
	 * @throws NoLowerAlphaException
	 */
	public static boolean hasLowerAlpha (String p) throws NoLowerAlphaException {
		for( int index = 0; index < p.length(); index++ ) {
			if(Character.isLowerCase(p.charAt(index))) {
				return true;
			}
		}
		throw new NoLowerAlphaException();
	}
	
	/**
	 * Checks the password Digit requirement - Password must contain a numeric character
	 * @param p - password string to be checked for Digit requirement
	 * @return true if meet Digit requirement
	 * @throws NoDigitException -thrown if does not meet Digit requirement
	 */
	public static boolean hasDigit (String p) throws NoDigitException{
		for (int index = 0; index < p.length(); index++) {
			if(Character.isDigit(p.charAt(index)))
				return true;
		}
		throw new NoDigitException();
	}
	
	/**
	 * Checks the password SpecialCharacter requirement - Password must contain a Special Character
	 * @param p - password string to be checked
	 * @return true if password has special character
	 * @throws NoSpecialCharacterException - thrown if does not meet SpecialCharacter requirement
	 */
	public static boolean hasSpecialChar(String p) throws NoSpecialCharacterException {
		Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
		Matcher matcher = pattern.matcher(p);
		if( !matcher.matches())
			return true;
		else
			throw new NoSpecialCharacterException();

		
	}
	
	/**
	 * Checks the password Sequence requirement - Password should not contain more than 2 of the same character in sequence
	 * @param p - password to be checked
	 * @return false if does NOT meet Sequence requirement
	 * @throws InvalidSequenceException - thrown if does not meet Sequence requirement
	 */
	public static boolean hasSameCharInSequence(String p) throws InvalidSequenceException{
		
		for(int index = 0; index < p.length()-2 ; index++) {
			//if string has 2 same characters in sequence
			if(p.charAt(index)==p.charAt(index+1))
			{
				//continue to check if it has 3 same characters in sequence
				if(p.charAt(index)==p.charAt(index+2))
					throw new InvalidSequenceException();
			}
		}
		return false;
		
	}
	
	/**
	 * checks if the password length is between 6 and 9 (inclusive)
	 * @param p - password string to be checked
	 * @return true if it meet the requirement
	 */
	public static boolean hasBetweenSixAndNineChars(String p) {
		if(p.length() >= 6 && p.length()<= 9)
			return true;
		else 
			return false;
	}
	
	/**
	 * @param p - password string to be checked
	 * @return true if it meet the requirement
	 * @throws LengthException
	 * @throws NoUpperAlphaException
	 * @throws NoLowerAlphaException
	 * @throws NoDigitException
	 * @throws NoSpecialCharacterException
	 * @throws InvalidSequenceException
	 * @return Return true if valid password (follows all rules from above)
	 */
	public static boolean isValidPassword(String p) throws LengthException,
															NoUpperAlphaException,
															NoLowerAlphaException,
															NoDigitException,
															NoSpecialCharacterException,
															InvalidSequenceException {

			if(isValidLength(p)&& hasUpperAlpha(p)&&hasLowerAlpha(p)&&
		       hasDigit(p)&& hasSpecialChar(p) && !hasSameCharInSequence(p))
			return true;
			else 
				return false;
			
		
	
	}
	
	/**
	 * 
	 * @param p - password to be checked
	 * @return true if password is valid but weak
	 * @throws WeakPasswordException
	 * @throws LengthException
	 * @throws NoUpperAlphaException
	 * @throws NoLowerAlphaException
	 * @throws NoDigitException
	 * @throws NoSpecialCharacterException
	 * @throws InvalidSequenceException
	 */
	public static boolean isWeakPassword(String p) throws WeakPasswordException {
		
		if( hasBetweenSixAndNineChars(p))
			throw new WeakPasswordException();
		else
			return false;
			
	}
	
	/**
	 * Reads a file of passwords and the passwords that failed the check will be added to an invalidPasswords with the reason
	 * @param passwords
	 * @return an array of invalidPasswords
	 * @throws LengthException
	 * @throws NoUpperAlphaException
	 * @throws NoLowerAlphaException
	 * @throws NoDigitException
	 * @throws NoSpecialCharacterException
	 * @throws InvalidSequenceException
	 */
	public static ArrayList<String> getInvalidPasswords (ArrayList<String> passwords) {
		ArrayList<String> invalidPasswords = new ArrayList<>();
		
		for (String onePassword: passwords) 
		{
			try{
				isValidPassword(onePassword);
				}
			catch(Exception e) {
				invalidPasswords.add(onePassword.concat(" -> ").concat(e.getMessage()));
			}
				
		}
		
		return invalidPasswords;
	}
}
