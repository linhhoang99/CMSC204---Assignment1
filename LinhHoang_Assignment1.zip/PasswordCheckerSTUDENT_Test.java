
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

/**
 * STUDENT tests for the methods of PasswordChecker
 * @author Linh Hoang
 * CMSC204
 * 9/16/20
 *
 */
public class PasswordCheckerSTUDENT_Test {
	PasswordCheckerUtility utility = new PasswordCheckerUtility();
	String p_compare1, p_compare2, p_compare3, 
		   p_validLength1, p_validLength2 , p_invalidLength,
		   p_hasUpper1, p_hasUpper2, p_noUpper,
		   p_hasLower1, p_hasLower2, p_noLower,
		   p_hasDigit1, p_hasDigit2, p_noDigit,
		   p_specialChar1, p_specialChar2, p_noSpecialChar,
		   p_repeatChar1, p_repeatChar2, p_noRepeatChar;
	
	boolean pass;
	
	@BeforeEach
	void setUp() throws Exception {
	// set that the method has not pass the test,
	// this will change to true if the test pass
	pass = false;
		
	// test the similarity
	p_compare1 = "lolipop147";
	p_compare2 = "lolipop147";
	p_compare3 = "lolipop148";
	
	// test length
	p_validLength1 = "123456";
	p_validLength2 = "1234567890";
	p_invalidLength = "12345";
	
	//test has upper case alpha
	p_hasUpper1 = "1234A4321";
	p_hasUpper2 = "adfhoanvaP";
	p_noUpper = "adsubgasd124!";
	
	// test lower case alpha
	p_hasLower1 = "123542@h";
	p_hasLower2 = "p91";
	p_noLower = "1230$";
	
	//test Digit
	p_hasDigit1 = "asdadsiP2";
	p_hasDigit2 = "!@$%#$^0";
	p_noDigit = "pasdbfew!#";
	
	//test special character
	p_specialChar1 = "ahoas9#";
	p_specialChar2 = "32305%";
	p_noSpecialChar = "asad";
	
	//test same characters
	p_noRepeatChar = "aabbcc123";
	p_repeatChar1 = "ads10hhh";
	p_repeatChar2 = "1234555";
	
	}

	@AfterEach
	void tearDown() throws Exception {
		pass = false;
	}
	
	@Test
	void testComparePasswords() throws UnmatchedException{
		//similar passwords
		utility.comparePasswords(p_compare1, p_compare2);
		try{
			// different passwords
			utility.comparePasswords(p_compare1, p_compare3);}
		catch(UnmatchedException ex) {
			pass = true;
		}
		assertTrue(pass);
	
	}

	
	@Test
	void testComparePasswordsWithReturn() {
		//similar passwords
		utility.comparePasswordsWithReturn(p_compare1, p_compare2);
		
		try{
			// different passwords
			utility.comparePasswords(p_compare1, p_compare3);}
		catch(UnmatchedException ex) {
			pass = true;
		}
		assertTrue(pass);
	
	}

	@Test
	void testIsValidLength() throws LengthException {
		PasswordCheckerUtility.isValidLength(p_validLength1);
		PasswordCheckerUtility.isValidLength(p_validLength2);
	}
	
	@Test
	void testInvalidLength() throws LengthException{
		try{
			utility.isValidLength(p_invalidLength);
		}
		catch( LengthException ex) {
			pass = true;
		}
		assertTrue(pass);
	}

	
	@Test
	void testHasUpperAlpha() throws NoUpperAlphaException {
		utility.hasUpperAlpha(p_hasUpper1);
		utility.hasUpperAlpha(p_hasUpper2);
	}
	

	void testNoUpperAlpha() throws NoUpperAlphaException{
		utility.hasUpperAlpha(p_hasUpper1);
	}
	
	
	
	
	@Test
	void testHasLowerAlpha() throws NoLowerAlphaException {
		utility.hasLowerAlpha(p_hasLower1);
		utility.hasLowerAlpha(p_hasLower2);
	}
	void testNoLowerALpha() throws NoLowerAlphaException{
		try {
			utility.hasLowerAlpha(p_noLower);
		}
		catch (NoLowerAlphaException ex) {
			pass = true;
		}
		assertTrue(pass);
	}

	@Test
	void testHasDigit() throws NoDigitException {
		utility.hasDigit(p_hasDigit1);
		utility.hasDigit(p_hasDigit2);
		}

	@Test
	void testNoDigit() throws NoDigitException{
		try {
			utility.hasDigit(p_noDigit);
		}
		catch (NoDigitException ex) {
			pass = true;;
		}
		assertTrue(pass);
	}
	
	void testHasSpecialChar() throws NoSpecialCharacterException{
		utility.hasSpecialChar(p_specialChar1);
		utility.hasSpecialChar(p_specialChar2);
	}

	void testNoSpecialChar() throws NoSpecialCharacterException{
		try {
			utility.hasSpecialChar(p_noSpecialChar);
		}
		catch (NoSpecialCharacterException ex) {
			pass = false;
		}
		assertTrue(pass);
	}
	
	
	@Test
	void testHasSameCharInSequence() throws InvalidSequenceException {
		boolean pass1, pass2;
		pass1 = false;
		pass2= false;
		
		try{
			utility.hasSameCharInSequence("pohhh");
		}
		catch(InvalidSequenceException ex) {

			pass1 = true;
		}
		try {
		utility.hasSameCharInSequence("wtnnnf");
		}
		catch(InvalidSequenceException ex) {
			pass2 = true;
		}

		assertTrue(pass1&&pass2);
	}
	

	void testNotHasSameCharInSequence () throws InvalidSequenceException{
		utility.hasSameCharInSequence(p_noRepeatChar);
	}
	
	@Test
	void testHasBetweenSixAndNineChars() {
		utility.hasBetweenSixAndNineChars("1a2s3d");
		utility.hasBetweenSixAndNineChars("1234567");
		utility.hasBetweenSixAndNineChars("!@#$%^&*(");
	}
	
	void testNotHasBetweenSixAndNineChars() {
		boolean notTrue = utility.hasBetweenSixAndNineChars("00");
		boolean notTrue2 = utility.hasBetweenSixAndNineChars("12345hihihhi"); 
		assertTrue(!notTrue);
		assertTrue(!notTrue2);
	}

	@Test
	void testIsValidPassword() throws LengthException, NoUpperAlphaException,
										NoLowerAlphaException, NoDigitException,
										NoSpecialCharacterException, InvalidSequenceException {
		utility.isValidPassword("9hoHo!?");
		utility.isValidPassword("!1@2#3$4%5aS");
		
	}
	
	void testNotValidPassword() throws LengthException, NoUpperAlphaException,
	                                   NoLowerAlphaException, NoDigitException,
	                                   NoSpecialCharacterException, InvalidSequenceException {
	boolean pass1 = false;
	boolean pass2 = false;
	try {
		utility.isValidPassword("upo");
	}catch(Exception ex) {
		pass1 = true;
	}
	
	try {
		utility.isValidPassword("asdfh1234");
	}catch(Exception ex) {
		pass2 = true;
	}
	
	assertTrue(pass1);
	assertTrue(pass2);
	}
	
	
	@Test
	void testIsWeakPassword() throws WeakPasswordException {
		boolean pass1 = false;
		boolean pass2 = false;
		try{
			utility.isWeakPassword("FopB54/@");
		}catch(Exception ex) {
			pass1 = true;
		}
		try {
		utility.isWeakPassword("1234567");
		}
		catch(Exception ex) {
			pass2 = true;
		}
		assertTrue(pass1);
		assertTrue(pass2);
		
	}
	
	void testNotWeakPassword() throws WeakPasswordException {
		boolean weak1 ,weak2;
		
		weak1 = utility.isWeakPassword("123");
		weak2 = utility.isWeakPassword("123456789poiu");
		
		assertTrue(!weak1);
		assertTrue(!weak2);
	}

	@Test
	void testGetInvalidPasswords() {
		 ArrayList<String> passwordArray = new ArrayList<>();
		 ArrayList<String> invalidArray = new ArrayList<>();
		 
		 //right
		 passwordArray.add("HoangAnh12/#");
		 passwordArray.add("Pruto93#&");
		 //wrong
		 passwordArray.add("qwer");
		 passwordArray.add("houptawesd");
		 passwordArray.add("upto1398");
		 passwordArray.add("aaaupeiv2@");
		 
		 invalidArray = utility.getInvalidPasswords(passwordArray);
		 assertEquals(invalidArray.size(), 4);
	}

}
